// with genesis block
const GENESIS_DATA = {
  timestamp: 1,
  lastHash: '-----',
  hash: 'hash-one',
  data: []
}
// object expoort
module.exports = {GENESIS_DATA};

 